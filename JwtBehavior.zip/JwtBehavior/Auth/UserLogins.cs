﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JwtBehavior.Auth
{
    public class UserLogins
    {
        public string pseudo { get; set; }
        public string Password { get; set; }

        public string? Email { get; set; }


    }
}
